CocoaPods Protocol Buffers Integration Tests
============================================

The sub directories are the basic projects as created by Xcode 6.3. They are
used to then drive `pod` and `xcodebuild` to ensure things integrate/build
as expected.

`run_tests.sh` defaults to running all the tests, invoke it with `--help` to
see the arguments to control what tests are run.
